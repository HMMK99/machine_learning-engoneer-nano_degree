Environment
	AWS Sagemaker
	kernel: conda_python3

liberaries
	pandas - numpy - re - os - sklearn - sagemaker

Summary of the Capstone Notebook
	Definition

		1.1 Domain Background

		1.2 Problem Statement

		1.3 dataset

		1.4 sulution statment

		1.5 Benchmark model

		1.6 metrics

		1.7 project design

	Analysis

		2.1 Gathering data

		2.2 Data exploring pre-processing

			Cleaning the data
			one-hot encoding the data
			visualize the symproms and diseases
			Devide the train and data sets
			Save the processed training dataset locally
		2.3 Training and testing the model

			Uploading the training data
			svc model
			Testing the model
			Deploying and Testing the endpoint

		2.4 Web application

			AWS Lambda
			HTML web app
	Conclusion

		3.1 Improvement

		3.2 Application

3.3 Application

References